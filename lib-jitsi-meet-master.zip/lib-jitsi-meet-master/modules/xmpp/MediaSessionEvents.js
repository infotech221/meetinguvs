export default {
    /**
     * Event triggered when the remote party signals it's receive video max frame height.
     */
    REMOTE_VIDEO_CONSTRAINTS_CHANGED: 'media_session.REMOTE_VIDEO_CONSTRAINTS_CHANGED'
};
