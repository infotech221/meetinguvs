module.exports = {
    'extends': [
        'eslint-config-jitsi'
    ]
};
