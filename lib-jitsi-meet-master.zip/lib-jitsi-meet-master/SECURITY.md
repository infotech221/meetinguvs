# Security

## Reporting security issues

We take security very seriously and develop all Jitsi projects to be secure and safe.

If you find (or simply suspect) a security issue in any of the Jitsi projects, please send us an email to security@jitsi.org.

**We encourage responsible disclosure for the sake of our users, so please reach out before posting in a public space.**
