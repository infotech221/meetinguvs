// For legacy purposes, preserve the UMD of the public API of the Jitsi Meet
// library (a.k.a. JitsiMeetJS).
module.exports = require('./JitsiMeetJS').default;
